'use strict'

let bearSound;
let camelSound;
let otterSound;


function preload() {
  bearSound = loadSound('../assets/animals/blackBear.mp3');
  camelSound = loadSound('../assets/animals/camel.mp3');
  otterSound = loadSound('../assets/animals/otterChirp.mp3');
}

function setup() {
}

function draw() {
}
